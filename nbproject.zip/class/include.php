<?php

include_once(dirname(__FILE__) . '/Database.php');
 
 include_once(dirname(__FILE__) . '/Message.php');
include_once(dirname(__FILE__) . '/Upload.php');
include_once(dirname(__FILE__) . '/Helper.php');
  
include_once(dirname(__FILE__) . '/Location.php'); 
include_once(dirname(__FILE__) . '/Center.php');