  <header class="header header-light">



    <nav class="navbar navbar-static-top navbar-expand-lg header-sticky">
      <div class="container-fluid">
        <div class="col-md-6">
          <a class="navbar-brand" href="index.php">
            <img class="img-fluid" src="images/logo-dark.svg" alt="logo">
          </a>
        </div>
        <!-- <div class="col-md-6 hidden-md" style="margin-top: 18px;">
          <a class="btn btn-primary btn-md" href="add-listing.php" target="_blank"> <i class="fa fa-plus-circle"></i>Add listing </a>
        </div>-->
      </div>
      <div class="d-block d-md-flex align-items-center">

        <div class="add-listing d-none d-sm-block">

          <a class="btn btn-primary btn-md" href="add-listing.php" target="_blank" style="width: 160px;
margin-right: 10px;">
            <i class="fa fa-plus-circle"></i>Add listing </a>

        </div>
      </div>
      </div>
    </nav>
  </header>